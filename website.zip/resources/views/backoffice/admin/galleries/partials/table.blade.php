<table class="table table-bordered">
<thead>
<tr>
<th>Name</th>
<th>Layout</th>
<th>Status</th>
</tr>
</thead>
<tbody>
@foreach($galleries as $gallery)
<tr>
<td>{{ $gallery->name }}</td>
<td>{{ $gallery->layout }}</td>
<td>{{ $gallery->is_active ? 'Active':'Inactive' }}</td>
</tr>
@endforeach
</tbody>
</table>
