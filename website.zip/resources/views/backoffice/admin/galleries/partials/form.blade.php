<div class="form-group">
<label>Name</label>
<input type="text" name="name" class="form-control">
</div>

<div class="form-group">
<label>Layout</label>
<input type="text" name="layout" class="form-control">
</div>
