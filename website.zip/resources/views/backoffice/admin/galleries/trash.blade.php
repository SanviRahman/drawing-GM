@extends('backoffice.layouts.app')

@section('content')
<div class="container-fluid">
<h4>Gallery Trash</h4>
@include('backoffice.admin.galleries.partials.table')
</div>
@endsection
