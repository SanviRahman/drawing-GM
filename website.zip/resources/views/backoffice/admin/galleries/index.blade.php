@extends('backoffice.layouts.app')

@section('content')
<div class="container-fluid">
    <h4>Gallery Management</h4>

    <div class="card">
        <div class="card-body">
            @include('backoffice.admin.galleries.partials.table')
        </div>
    </div>
</div>
@endsection
