<?php

namespace App\Http\Controllers\Backoffice\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PricingAddonController extends Controller
{
    //
}
