<?php

namespace App\Http\Controllers\Backoffice\Admin;

use App\Http\Controllers\Controller;
use App\Models\Gallery;
use Illuminate\Http\Request;

class GalleryController extends Controller
{
    public function index(Request $request)
    {
        $galleries = Gallery::with('items')->latest('id')->paginate(15);

        if ($request->ajax()) {
            return response()->json([
                'html' => view('backoffice.admin.galleries.partials.table', compact('galleries'))->render()
            ]);
        }

        return view('backoffice.admin.galleries.index', compact('galleries'));
    }

    public function create(Request $request)
    {
        abort_unless($request->ajax(),404);

        return response()->json([
            'html'=>view('backoffice.admin.galleries.partials.form')->render()
        ]);
    }

    public function store(Request $request)
    {
        $data=$request->validate([
            'name'=>'required|string|max:255',
            'layout'=>'nullable|string|max:100',
            'is_active'=>'required|boolean'
        ]);

        Gallery::create($data);

        return response()->json([
            'success'=>true,
            'message'=>'Gallery created successfully.'
        ]);
    }

    public function edit(Request $request, Gallery $gallery)
    {
        abort_unless($request->ajax(),404);

        return response()->json([
            'html'=>view('backoffice.admin.galleries.partials.form',compact('gallery'))->render()
        ]);
    }

    public function update(Request $request, Gallery $gallery)
    {
        $gallery->update($request->validate([
            'name'=>'required|string|max:255',
            'layout'=>'nullable|string|max:100',
            'is_active'=>'required|boolean'
        ]));

        return response()->json([
            'success'=>true,
            'message'=>'Gallery updated successfully.'
        ]);
    }

    public function destroy(Gallery $gallery)
    {
        $gallery->delete();

        return response()->json([
            'success'=>true,
            'message'=>'Gallery moved to trash.'
        ]);
    }

    public function trash()
    {
        $galleries=Gallery::onlyTrashed()->latest('deleted_at')->paginate(15);

        return view('backoffice.admin.galleries.trash',compact('galleries'));
    }

    public function restore($id)
    {
        Gallery::onlyTrashed()->findOrFail($id)->restore();

        return response()->json([
            'success'=>true,
            'message'=>'Gallery restored.'
        ]);
    }

    public function forceDelete($id)
    {
        Gallery::onlyTrashed()->findOrFail($id)->forceDelete();

        return response()->json([
            'success'=>true,
            'message'=>'Gallery permanently deleted.'
        ]);
    }
}
