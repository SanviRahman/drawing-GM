<div class="table-responsive">
    <table class="table table-hover border-bottom pricing-item-table mb-0 text-nowrap">
        <thead class="thead-light">
            <tr>
                <th style="width:40px;" class="text-center"><input type="checkbox" id="checkAll"></th>
                <th>Package</th>
                <th>Label</th>
                <th>Type</th>
                <th>Price</th>
                <th>Unit</th>
                <th class="text-center">Order</th>
                <th class="text-center"><?php echo e(($isTrash ?? false) ? 'Deleted' : 'Status'); ?></th>
                <th style="width:190px;" class="text-center">Actions</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center"><input type="checkbox" class="row-checkbox" value="<?php echo e($item->id); ?>"></td>
                    <td>
                        <strong><?php echo e($item->pricingPackage?->name ?? 'Deleted package'); ?></strong>
                        <?php if($item->pricingPackage?->service): ?>
                            <small class="text-muted d-block"><?php echo e($item->pricingPackage->service->name); ?></small>
                        <?php elseif($item->pricingPackage?->location): ?>
                            <small class="text-muted d-block"><?php echo e($item->pricingPackage->location->name); ?></small>
                        <?php else: ?>
                            <small class="text-muted d-block">Global</small>
                        <?php endif; ?>
                    </td>
                    <td class="font-weight-bold"><?php echo e($item->label); ?></td>
                    <td><span class="badge badge-info"><?php echo e($item->price_type_label); ?></span></td>
                    <td><?php echo e($item->display_price); ?></td>
                    <td><?php echo e($item->unit ?: '—'); ?></td>
                    <td class="text-center"><?php echo e($item->sort_order); ?></td>

                    <td class="text-center">
                        <?php if($isTrash ?? false): ?>
                            <span class="text-muted small"><?php echo e($item->deleted_at?->format('d M Y')); ?></span>
                        <?php else: ?>
                            <span class="badge badge-<?php echo e($item->is_active ? 'success' : 'secondary'); ?>"><?php echo e($item->is_active ? 'Active' : 'Inactive'); ?></span>
                        <?php endif; ?>
                    </td>

                    <td class="text-center">
                        <?php if($isTrash ?? false): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_restore')): ?>
                                <button type="button" class="btn btn-sm btn-outline-success btn-restore" data-url="<?php echo e(route('admin.pricing_items.restore', $item->id)); ?>" title="Restore"><i class="fas fa-undo"></i></button>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_force_delete')): ?>
                                <button type="button" class="btn btn-sm btn-outline-danger btn-force-delete" data-url="<?php echo e(route('admin.pricing_items.force_delete', $item->id)); ?>" title="Permanent Delete"><i class="fas fa-trash-alt"></i></button>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_view')): ?>
                                <button type="button" class="btn btn-sm btn-outline-info btn-show" data-url="<?php echo e(route('admin.pricing_items.show', $item->id)); ?>" title="View"><i class="fas fa-eye"></i></button>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_update')): ?>
                                <button type="button" class="btn btn-sm btn-outline-primary btn-edit" data-url="<?php echo e(route('admin.pricing_items.edit', $item->id)); ?>" title="Edit"><i class="fas fa-pen"></i></button>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_toggle')): ?>
                                <button type="button" class="btn btn-sm btn-outline-warning btn-toggle" data-url="<?php echo e(route('admin.pricing_items.toggle', $item->id)); ?>" title="<?php echo e($item->is_active ? 'Deactivate' : 'Activate'); ?>"><i class="fas fa-<?php echo e($item->is_active ? 'pause' : 'play'); ?>"></i></button>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_duplicate')): ?>
                                <button type="button" class="btn btn-sm btn-outline-secondary btn-duplicate" data-url="<?php echo e(route('admin.pricing_items.duplicate', $item->id)); ?>" title="Duplicate"><i class="fas fa-copy"></i></button>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_delete')): ?>
                                <button type="button" class="btn btn-sm btn-outline-danger btn-delete" data-url="<?php echo e(route('admin.pricing_items.destroy', $item->id)); ?>" title="Trash"><i class="fas fa-trash"></i></button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="9" class="text-center py-5"><div class="text-muted"><i class="fas fa-tags fa-3x mb-3 text-light"></i><h5 class="font-weight-bold">No pricing items found</h5><p class="mb-0 small">Create a pricing item or adjust your filters.</p></div></td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php if($items->hasPages()): ?>
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center px-3 py-3 border-top bg-light">
        <div class="text-muted small font-weight-bold mb-2 mb-md-0">Showing <?php echo e($items->firstItem() ?? 0); ?> to <?php echo e($items->lastItem() ?? 0); ?> of <?php echo e($items->total()); ?> entries</div>
        <div class="m-0 pagination-sm"><?php echo $items->appends(request()->query())->links('pagination::bootstrap-4'); ?></div>
    </div>
<?php endif; ?>
<?php /**PATH D:\drawing\website\resources\views/backoffice/admin/pricing_items/partials/table.blade.php ENDPATH**/ ?>