<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<div id="pricing-addon-manager" class="container-fluid py-3" data-index-url="<?php echo e(route('admin.pricing_addons.index')); ?>" data-create-url="<?php echo e(route('admin.pricing_addons.create')); ?>" data-bulk-url="<?php echo e(route('admin.pricing_addons.multiple_action')); ?>">
    <div class="d-flex align-items-center flex-wrap mb-3" style="gap:6px;">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_create')): ?>
            <button type="button" class="btn btn-primary btn-sm font-weight-bold shadow-sm" id="btnAddRecord"><i class="fas fa-plus mr-1"></i>Add Pricing Add-on</button>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_trash')): ?>
            <a href="<?php echo e(route('admin.pricing_addons.trashed')); ?>" class="btn btn-outline-danger btn-sm font-weight-bold shadow-sm"><i class="fas fa-trash-alt mr-1"></i>Trash Bin</a>
        <?php endif; ?>

        <select id="bulk_action" class="form-control form-control-sm shadow-none" style="width:190px;">
            <option value="">-- Bulk Actions --</option>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_toggle')): ?>
                <option value="activate">Activate</option>
                <option value="deactivate">Deactivate</option>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_delete')): ?>
                <option value="delete">Move to Trash</option>
            <?php endif; ?>
        </select>
        <button type="button" class="btn btn-secondary btn-sm font-weight-bold px-3 shadow-sm" id="btnApplyBulk">APPLY</button>
    </div>

    <div class="card shadow-sm border-0 mb-3"><div class="card-body px-3 py-2"><form id="filterForm" method="GET" action="<?php echo e(route('admin.pricing_addons.index')); ?>"><div class="row align-items-end">
        <div class="col-md-3 mb-2 mb-md-0"><label for="filter_type" class="text-muted small font-weight-bold text-uppercase mb-1">Price Type</label><select name="price_type" id="filter_type" class="form-control form-control-sm shadow-none"><option value="">All Price Types</option><option value="fixed" <?php echo e(request('price_type') === 'fixed' ? 'selected' : ''); ?>>Fixed</option><option value="from" <?php echo e(request('price_type') === 'from' ? 'selected' : ''); ?>>From</option><option value="range" <?php echo e(request('price_type') === 'range' ? 'selected' : ''); ?>>Range</option><option value="call" <?php echo e(request('price_type') === 'call' ? 'selected' : ''); ?>>Call for Price</option></select></div>
        <div class="col-md-2 mb-2 mb-md-0"><label for="filter_status" class="text-muted small font-weight-bold text-uppercase mb-1">Status</label><select name="status" id="filter_status" class="form-control form-control-sm shadow-none"><option value="">All Statuses</option><option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option><option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option></select></div>
        <div class="col-md-6 mb-2 mb-md-0"><label for="table_search" class="text-muted small font-weight-bold text-uppercase mb-1">Search</label><div class="input-group input-group-sm"><input type="text" name="search" id="table_search" class="form-control shadow-none" value="<?php echo e(request('search')); ?>" autocomplete="off" placeholder="Name, description or unit..."><div class="input-group-append"><button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button></div></div></div>
        <div class="col-md-1"><button type="button" class="btn btn-outline-danger btn-sm btn-block font-weight-bold shadow-sm" id="btnResetFilter"><i class="fas fa-sync-alt"></i></button></div>
    </div></form></div></div>

    <div class="card shadow-sm border-0"><div class="card-header bg-white px-3 py-3 border-bottom"><h3 class="card-title font-weight-bold text-dark mb-0"><i class="fas fa-puzzle-piece text-primary mr-1"></i>Pricing Add-ons List</h3></div><div class="card-body p-0" id="content-wrapper" style="min-height:340px;"><?php echo $__env->make('backoffice.admin.pricing_addons.partials.table', ['addons' => $addons, 'isTrash' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div></div>
</div>

<?php echo $__env->make('backoffice.admin.pricing_addons.partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startPush('css'); ?>
<style>.pricing-addon-table td{vertical-align:middle}.pricing-addon-thumb{width:54px;height:54px;object-fit:cover}.pricing-addon-empty-thumb{width:54px;height:54px;display:flex;align-items:center;justify-content:center}</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backoffice.admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\drawing\website\resources\views/backoffice/admin/pricing_addons/index.blade.php ENDPATH**/ ?>