

<?php $__env->startSection('content'); ?>
<div id="page-manager" class="container-fluid py-3" data-mode="active" data-index-url="<?php echo e(route('admin.pages.index')); ?>" data-create-url="<?php echo e(route('admin.pages.create')); ?>" data-bulk-url="<?php echo e(route('admin.pages.multiple_action')); ?>" data-trash-url="<?php echo e(route('admin.pages.trashed')); ?>">
    <div class="d-flex align-items-center flex-wrap mb-3" style="gap:6px;">
        <?php if(auth('admin')->user()?->can('page_create')): ?>
            <button type="button" class="btn btn-primary btn-sm font-weight-bold shadow-sm" id="btnAddRecord"><i class="fas fa-plus mr-1"></i>Add New Page</button>
        <?php endif; ?>
        <?php if(auth('admin')->user()?->can('page_trash')): ?>
            <a href="<?php echo e(route('admin.pages.trashed')); ?>" class="btn btn-outline-danger btn-sm font-weight-bold shadow-sm"><i class="fas fa-trash-alt mr-1"></i>Trash Bin</a>
        <?php endif; ?>
        <select id="bulk_action" class="form-control form-control-sm shadow-none" style="width:190px;">
            <option value="">-- Bulk Actions --</option>
            <?php if(auth('admin')->user()?->can('page_publish')): ?><option value="publish">Publish</option><?php endif; ?>
            <?php if(auth('admin')->user()?->can('page_unpublish')): ?><option value="unpublish">Move to Draft</option><?php endif; ?>
            <?php if(auth('admin')->user()?->can('page_update')): ?><option value="archive">Archive</option><?php endif; ?>
            <?php if(auth('admin')->user()?->can('page_delete')): ?><option value="delete">Move to Trash</option><?php endif; ?>
        </select>
        <button type="button" class="btn btn-secondary btn-sm font-weight-bold px-3 shadow-sm" id="btnApplyBulk">APPLY</button>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body px-3 py-2">
            <div class="row align-items-end">
                <div class="col-md-2 mb-2 mb-md-0">
                    <label for="filter_status" class="text-muted small font-weight-bold text-uppercase mb-1">Status</label>
                    <select id="filter_status" class="form-control form-control-sm shadow-none"><option value="">All Statuses</option><?php $__currentLoopData = \App\Models\Page::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>"><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                </div>
                <div class="col-md-2 mb-2 mb-md-0">
                    <label for="filter_template" class="text-muted small font-weight-bold text-uppercase mb-1">Template</label>
                    <select id="filter_template" class="form-control form-control-sm shadow-none"><option value="">All Templates</option><?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($template); ?>"><?php echo e($template); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                </div>
                <div class="col-md-2 mb-2 mb-md-0">
                    <label for="filter_homepage" class="text-muted small font-weight-bold text-uppercase mb-1">Homepage</label>
                    <select id="filter_homepage" class="form-control form-control-sm shadow-none"><option value="">All Pages</option><option value="1">Homepage Only</option><option value="0">Non-homepage</option></select>
                </div>
                <div class="col-md-4 mb-2 mb-md-0">
                    <label for="table_search" class="text-muted small font-weight-bold text-uppercase mb-1">Search Pages</label>
                    <div class="input-group input-group-sm"><input type="text" id="table_search" class="form-control shadow-none" autocomplete="off" placeholder="Search title, slug or excerpt..."><div class="input-group-append"><button type="button" class="btn btn-outline-secondary" id="btnClearSearch" title="Clear"><i class="fas fa-times"></i></button><button type="button" class="btn btn-primary" id="btnSearch" title="Search"><i class="fas fa-search"></i></button></div></div>
                </div>
                <div class="col-md-2"><button type="button" class="btn btn-outline-danger btn-sm btn-block font-weight-bold shadow-sm" id="btnResetFilter"><i class="fas fa-sync-alt mr-1"></i>Reset</button></div>
            </div>
        </div>
    </div>

    <?php if(auth('admin')->user()?->can('page_list')): ?>
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white px-3 py-3 border-bottom"><h3 class="card-title font-weight-bold text-dark mb-0"><i class="fas fa-file-alt text-primary mr-1"></i>Pages List</h3></div>
            <div class="card-body p-0" id="content-wrapper" style="min-height:340px;"><?php echo $__env->make('backoffice.admin.pages.partials.table', ['pages' => $pages, 'isTrash' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning border-0 shadow-sm mt-4 font-weight-bold"><i class="fas fa-exclamation-triangle mr-2"></i>You do not have permission to view pages.</div>
    <?php endif; ?>
</div>

<div class="modal fade" id="ajaxModal" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true"><div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document"><div class="modal-content border-0 shadow-lg"><div class="modal-header border-bottom-0 pb-0"><h5 class="modal-title font-weight-bold text-primary" id="modal-title">Pages Management</h5><button type="button" class="close px-4 shadow-none" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button></div><div class="modal-body p-4" id="modal-body"></div></div></div></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startPush('css'); ?>
<style>#content-wrapper.loading{opacity:.5;pointer-events:none;transition:opacity .3s ease-in-out}.page-table td{vertical-align:middle}.page-title-cell{min-width:240px}</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('js'); ?>
<?php echo $__env->make('backoffice.admin.pages.partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backoffice.admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\drawing\website\resources\views/backoffice/admin/pages/index.blade.php ENDPATH**/ ?>