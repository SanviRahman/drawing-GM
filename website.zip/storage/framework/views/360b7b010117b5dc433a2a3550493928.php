<div class="row">
    <div class="col-md-8 mb-2"><small class="text-muted d-block">Pricing Package</small><strong><?php echo e($pricingItem->pricingPackage?->name ?? 'Deleted package'); ?></strong></div>
    <div class="col-md-4 mb-2"><small class="text-muted d-block">Status</small><span class="badge badge-<?php echo e($pricingItem->is_active ? 'success' : 'secondary'); ?> px-2 py-1"><?php echo e($pricingItem->is_active ? 'Active' : 'Inactive'); ?></span></div>

    <div class="col-md-8 mb-2"><small class="text-muted d-block">Label</small><strong><?php echo e($pricingItem->label); ?></strong></div>
    <div class="col-md-4 mb-2"><small class="text-muted d-block">Price Type</small><span class="badge badge-info px-2 py-1"><?php echo e($pricingItem->price_type_label); ?></span></div>

    <div class="col-md-12 mb-2"><small class="text-muted d-block">Display Price</small><div class="border rounded bg-light px-3 py-2 font-weight-bold"><?php echo e($pricingItem->display_price); ?></div></div>

    <div class="col-md-3 mb-2"><small class="text-muted d-block">Amount</small><span><?php echo e($pricingItem->amount !== null ? number_format((float) $pricingItem->amount, 2) : '—'); ?></span></div>
    <div class="col-md-3 mb-2"><small class="text-muted d-block">Max Amount</small><span><?php echo e($pricingItem->amount_max !== null ? number_format((float) $pricingItem->amount_max, 2) : '—'); ?></span></div>
    <div class="col-md-3 mb-2"><small class="text-muted d-block">Unit</small><span><?php echo e($pricingItem->unit ?: '—'); ?></span></div>
    <div class="col-md-3 mb-2"><small class="text-muted d-block">Order</small><span><?php echo e($pricingItem->sort_order); ?></span></div>

    <div class="col-md-6 mb-2"><small class="text-muted d-block">Prefix</small><span><?php echo e($pricingItem->prefix ?: '—'); ?></span></div>
    <div class="col-md-6 mb-2"><small class="text-muted d-block">Suffix</small><span><?php echo e($pricingItem->suffix ?: '—'); ?></span></div>

    <div class="col-md-6 mt-2"><small class="text-muted">Created: <?php echo e($pricingItem->created_at?->format('d M Y, h:i A') ?? '—'); ?></small></div>
    <div class="col-md-6 mt-2 text-md-right"><small class="text-muted">Updated: <?php echo e($pricingItem->updated_at?->format('d M Y, h:i A') ?? '—'); ?></small></div>
</div>
<?php /**PATH D:\drawing\website\resources\views/backoffice/admin/pricing_items/partials/show.blade.php ENDPATH**/ ?>