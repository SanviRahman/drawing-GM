<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<div id="pricing-item-manager" class="container-fluid py-3" data-mode="active" data-index-url="<?php echo e(route('admin.pricing_items.index')); ?>" data-create-url="<?php echo e(route('admin.pricing_items.create')); ?>" data-bulk-url="<?php echo e(route('admin.pricing_items.multiple_action')); ?>">
    <div class="d-flex align-items-center flex-wrap mb-3" style="gap:6px;">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_create')): ?>
            <button type="button" class="btn btn-primary btn-sm font-weight-bold shadow-sm" id="btnAddRecord"><i class="fas fa-plus mr-1"></i>Add Pricing Item</button>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_trash')): ?>
            <a href="<?php echo e(route('admin.pricing_items.trashed')); ?>" class="btn btn-outline-danger btn-sm font-weight-bold shadow-sm"><i class="fas fa-trash-alt mr-1"></i>Trash Bin</a>
        <?php endif; ?>

        <select id="bulk_action" class="form-control form-control-sm shadow-none" style="width:190px;">
            <option value="">-- Bulk Actions --</option>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_toggle')): ?>
                <option value="activate">Activate</option>
                <option value="deactivate">Deactivate</option>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_delete')): ?>
                <option value="delete">Move to Trash</option>
            <?php endif; ?>
        </select>

        <button type="button" class="btn btn-secondary btn-sm font-weight-bold px-3 shadow-sm" id="btnApplyBulk">APPLY</button>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body px-3 py-2">
            <form id="filterForm" method="GET" action="<?php echo e(route('admin.pricing_items.index')); ?>">
                <div class="row align-items-end">
                    <div class="col-md-3 mb-2 mb-md-0">
                        <label for="filter_package" class="text-muted small font-weight-bold text-uppercase mb-1">Package</label>
                        <select name="pricing_package_id" id="filter_package" class="form-control form-control-sm shadow-none">
                            <option value="">All Packages</option>
                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($package->id); ?>" <?php echo e((string) request('pricing_package_id') === (string) $package->id ? 'selected' : ''); ?>><?php echo e($package->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2 mb-2 mb-md-0">
                        <label for="filter_type" class="text-muted small font-weight-bold text-uppercase mb-1">Price Type</label>
                        <select name="price_type" id="filter_type" class="form-control form-control-sm shadow-none">
                            <option value="">All Types</option>
                            <option value="fixed" <?php echo e(request('price_type') === 'fixed' ? 'selected' : ''); ?>>Fixed</option>
                            <option value="from" <?php echo e(request('price_type') === 'from' ? 'selected' : ''); ?>>From</option>
                            <option value="range" <?php echo e(request('price_type') === 'range' ? 'selected' : ''); ?>>Range</option>
                            <option value="call" <?php echo e(request('price_type') === 'call' ? 'selected' : ''); ?>>Call for Price</option>
                        </select>
                    </div>

                    <div class="col-md-2 mb-2 mb-md-0">
                        <label for="filter_status" class="text-muted small font-weight-bold text-uppercase mb-1">Status</label>
                        <select name="status" id="filter_status" class="form-control form-control-sm shadow-none">
                            <option value="">All Statuses</option>
                            <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>

                    <div class="col-md-3 mb-2 mb-md-0">
                        <label for="table_search" class="text-muted small font-weight-bold text-uppercase mb-1">Search Items</label>
                        <div class="input-group input-group-sm"><input type="text" name="search" id="table_search" class="form-control shadow-none" value="<?php echo e(request('search')); ?>" autocomplete="off" placeholder="Search label, package, unit..."><div class="input-group-append"><button type="button" class="btn btn-outline-secondary" id="btnClearSearch" title="Clear"><i class="fas fa-times"></i></button><button class="btn btn-primary" type="submit" title="Search"><i class="fas fa-search"></i></button></div></div>
                    </div>

                    <div class="col-md-2"><button type="button" class="btn btn-outline-danger btn-sm btn-block font-weight-bold shadow-sm" id="btnResetFilter"><i class="fas fa-sync-alt mr-1"></i>Reset</button></div>
                </div>
            </form>
        </div>
    </div>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_item_list')): ?>
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white px-3 py-3 border-bottom"><h3 class="card-title font-weight-bold text-dark mb-0"><i class="fas fa-list text-primary mr-1"></i>Pricing Items List</h3></div>
            <div class="card-body p-0" id="content-wrapper" style="min-height:340px;"><?php echo $__env->make('backoffice.admin.pricing_items.partials.table', ['items' => $items, 'isTrash' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning border-0 shadow-sm"><i class="fas fa-exclamation-triangle mr-2"></i>You do not have permission to view pricing items.</div>
    <?php endif; ?>
</div>

<div class="modal fade" id="ajaxModal" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-centered" role="document"><div class="modal-content border-0 shadow-lg"><div class="modal-header py-2"><h5 class="modal-title font-weight-bold text-primary mb-0" id="modal-title">Pricing Item</h5><button type="button" class="close shadow-none" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button></div><div class="modal-body p-3" id="modal-body"></div></div></div></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startPush('css'); ?>
<style>#content-wrapper.loading{opacity:.55;pointer-events:none;transition:opacity .2s ease}.pricing-item-table td{vertical-align:middle}</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('js'); ?>
<?php echo $__env->make('backoffice.admin.pricing_items.partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backoffice.admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\drawing\website\resources\views/backoffice/admin/pricing_items/index.blade.php ENDPATH**/ ?>