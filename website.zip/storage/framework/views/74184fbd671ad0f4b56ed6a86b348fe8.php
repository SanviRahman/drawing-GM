<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<div id="service-feature-manager" class="container-fluid py-3">
    <div class="d-flex align-items-center flex-wrap mb-3" style="gap:6px;">
        <?php if(auth('admin')->user()?->can('service_feature_create')): ?>
            <button type="button" class="btn btn-primary btn-sm font-weight-bold shadow-sm btn-create" data-url="<?php echo e(route('admin.service_features.create')); ?>"><i class="fas fa-plus mr-1"></i>Add New Feature</button>
        <?php endif; ?>

        <?php if(auth('admin')->user()?->can('service_feature_trash')): ?>
            <a href="<?php echo e(route('admin.service_features.trashed')); ?>" class="btn btn-outline-danger btn-sm font-weight-bold shadow-sm"><i class="fas fa-trash-alt mr-1"></i>Trash Bin</a>
        <?php endif; ?>

        <select id="bulkAction" class="form-control form-control-sm shadow-none" style="width:190px;">
            <option value="">-- Bulk Actions --</option>
            <?php if(auth('admin')->user()?->can('service_feature_toggle')): ?>
                <option value="activate">Activate</option>
                <option value="deactivate">Deactivate</option>
            <?php endif; ?>
            <?php if(auth('admin')->user()?->can('service_feature_delete')): ?>
                <option value="delete">Move to Trash</option>
            <?php endif; ?>
        </select>

        <button type="button" class="btn btn-secondary btn-sm font-weight-bold px-3 shadow-sm" id="applyBulk">APPLY</button>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body px-3 py-2">
            <form id="filterForm" method="GET" action="<?php echo e(route('admin.service_features.index')); ?>">
                <div class="row align-items-end">
                    <div class="col-md-3 mb-2 mb-md-0">
                        <label for="filter_service" class="text-muted small font-weight-bold text-uppercase mb-1">Service</label>
                        <select name="service_id" id="filter_service" class="form-control form-control-sm shadow-none">
                            <option value="">All Services</option>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($service->id); ?>" <?php echo e((string) request('service_id') === (string) $service->id ? 'selected' : ''); ?>><?php echo e($service->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2 mb-2 mb-md-0">
                        <label for="filter_status" class="text-muted small font-weight-bold text-uppercase mb-1">Status</label>
                        <select name="status" id="filter_status" class="form-control form-control-sm shadow-none">
                            <option value="">All Statuses</option>
                            <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>

                    <div class="col-md-5 mb-2 mb-md-0">
                        <label for="table_search" class="text-muted small font-weight-bold text-uppercase mb-1">Search Features</label>
                        <div class="input-group input-group-sm">
                            <input type="text" name="search" id="table_search" class="form-control shadow-none" value="<?php echo e(request('search')); ?>" autocomplete="off" placeholder="Search title, description or icon...">
                            <div class="input-group-append"><button class="btn btn-primary" type="submit" title="Search"><i class="fas fa-search"></i></button></div>
                        </div>
                    </div>

                    <div class="col-md-2"><button type="button" class="btn btn-outline-danger btn-sm btn-block font-weight-bold shadow-sm btn-reset-filter"><i class="fas fa-sync-alt mr-1"></i>Reset</button></div>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white px-3 py-3 border-bottom"><h3 class="card-title font-weight-bold text-dark mb-0"><i class="fas fa-list-ul text-primary mr-1"></i>Service Features List</h3></div>
        <div class="card-body p-0" id="tableContainer" style="min-height:340px;"><?php echo $__env->make('backoffice.admin.service_features.partials.table', ['features' => $features], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
    </div>
</div>

<?php echo $__env->make('backoffice.admin.service_features.partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>


<?php $__env->startPush('css'); ?>
<style>.service-feature-table td{vertical-align:middle}</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backoffice.admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\drawing\website\resources\views/backoffice/admin/service_features/index.blade.php ENDPATH**/ ?>