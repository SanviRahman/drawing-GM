<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<div id="pricing-package-manager" class="container-fluid py-3">
    <div class="d-flex align-items-center flex-wrap mb-3" style="gap:6px;">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_package_create')): ?>
            <button type="button" class="btn btn-primary btn-sm font-weight-bold shadow-sm btn-create" data-url="<?php echo e(route('admin.pricing_packages.create')); ?>"><i class="fas fa-plus mr-1"></i>Add Pricing Package</button>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_package_trash')): ?>
            <a href="<?php echo e(route('admin.pricing_packages.trashed')); ?>" class="btn btn-outline-danger btn-sm font-weight-bold shadow-sm"><i class="fas fa-trash-alt mr-1"></i>Trash Bin</a>
        <?php endif; ?>

        <select id="bulkAction" class="form-control form-control-sm shadow-none" style="width:190px;">
            <option value="">-- Bulk Actions --</option>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_package_toggle')): ?>
                <option value="activate">Activate</option>
                <option value="deactivate">Deactivate</option>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_package_delete')): ?>
                <option value="delete">Move to Trash</option>
            <?php endif; ?>
        </select>
        <button type="button" class="btn btn-secondary btn-sm font-weight-bold px-3 shadow-sm" id="applyBulk">APPLY</button>
    </div>

    <div class="card shadow-sm border-0 mb-3"><div class="card-body px-3 py-2"><form id="filterForm" method="GET" action="<?php echo e(route('admin.pricing_packages.index')); ?>"><div class="row align-items-end">
        <div class="col-md-2 mb-2 mb-md-0"><label for="filter_service" class="text-muted small font-weight-bold text-uppercase mb-1">Service</label><select name="service_id" id="filter_service" class="form-control form-control-sm shadow-none"><option value="">All Services</option>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($service->id); ?>" <?php echo e((string) request('service_id') === (string) $service->id ? 'selected' : ''); ?>><?php echo e($service->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></div>
        <div class="col-md-2 mb-2 mb-md-0"><label for="filter_location" class="text-muted small font-weight-bold text-uppercase mb-1">Location</label><select name="location_id" id="filter_location" class="form-control form-control-sm shadow-none"><option value="">All Locations</option>
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($location->id); ?>" <?php echo e((string) request('location_id') === (string) $location->id ? 'selected' : ''); ?>><?php echo e($location->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></div>
        <div class="col-md-2 mb-2 mb-md-0"><label for="filter_status" class="text-muted small font-weight-bold text-uppercase mb-1">Status</label><select name="status" id="filter_status" class="form-control form-control-sm shadow-none"><option value="">All Statuses</option><option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option><option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option></select></div>
        <div class="col-md-2 mb-2 mb-md-0"><label for="filter_featured" class="text-muted small font-weight-bold text-uppercase mb-1">Featured</label><select name="featured" id="filter_featured" class="form-control form-control-sm shadow-none"><option value="">All</option><option value="yes" <?php echo e(request('featured') === 'yes' ? 'selected' : ''); ?>>Featured</option><option value="no" <?php echo e(request('featured') === 'no' ? 'selected' : ''); ?>>Not Featured</option></select></div>
        <div class="col-md-3 mb-2 mb-md-0"><label for="table_search" class="text-muted small font-weight-bold text-uppercase mb-1">Search</label><div class="input-group input-group-sm"><input type="text" name="search" id="table_search" class="form-control shadow-none" value="<?php echo e(request('search')); ?>" autocomplete="off" placeholder="Name, subtitle, badge, currency..."><div class="input-group-append"><button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button></div></div></div>
        <div class="col-md-1"><button type="button" class="btn btn-outline-danger btn-sm btn-block font-weight-bold shadow-sm btn-reset-filter"><i class="fas fa-sync-alt"></i></button></div>
    </div></form></div></div>

    <div class="card shadow-sm border-0"><div class="card-header bg-white px-3 py-3 border-bottom"><h3 class="card-title font-weight-bold text-dark mb-0"><i class="fas fa-tags text-primary mr-1"></i>Pricing Packages List</h3></div><div class="card-body p-0" id="tableContainer" style="min-height:340px;"><?php echo $__env->make('backoffice.admin.pricing_packages.partials.table', ['packages' => $packages], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div></div>
</div>

<?php echo $__env->make('backoffice.admin.pricing_packages.partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startPush('css'); ?>
<style>.pricing-package-table td{vertical-align:middle}</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backoffice.admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\drawing\website\resources\views/backoffice/admin/pricing_packages/index.blade.php ENDPATH**/ ?>