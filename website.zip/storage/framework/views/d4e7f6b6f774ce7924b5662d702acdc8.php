<?php
    $isTrash = $isTrash ?? false;
    $admin = auth('admin')->user();
    $canView = $admin?->can('location_view') ?? false;
    $canUpdate = $admin?->can('location_update') ?? false;
    $canDelete = $admin?->can('location_delete') ?? false;
    $canPublish = $admin?->can('location_publish') ?? false;
    $canUnpublish = $admin?->can('location_unpublish') ?? false;
    $canDuplicate = $admin?->can('location_duplicate') ?? false;
    $canRestore = $admin?->can('location_restore') ?? false;
    $canForceDelete = $admin?->can('location_force_delete') ?? false;
?>

<div class="table-responsive">
    <table class="table table-hover mb-0 location-table">
        <thead class="thead-light"><tr><th class="text-center" style="width:45px;"><input type="checkbox" id="checkAll" aria-label="Select all"></th><th style="width:90px;">Preview</th><th>Location</th><th style="width:150px;">Region</th><th style="width:105px;">Status</th><th style="width:80px;">Order</th><th style="width:130px;">Published</th><th class="text-right" style="width:190px;">Actions</th></tr></thead>
        <tbody>
            <?php if($locations->count() > 0): ?>
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $previewUrl = null;
                        try {
                            $previewUrl = $item->getFirstMediaUrl('hero_desktop') ?: $item->getFirstMediaUrl('hero_mobile');
                        } catch (\Throwable) {
                            $previewUrl = null;
                        }
                    ?>

                    <tr>
                        <td class="text-center"><input type="checkbox" class="row-checkbox" value="<?php echo e($item->id); ?>" aria-label="Select <?php echo e($item->name); ?>"></td>

                        <td>
                            <div class="border rounded bg-light d-flex align-items-center justify-content-center overflow-hidden" style="width:64px;height:54px;">
                                <?php if($previewUrl): ?>
                                    <img src="<?php echo e($previewUrl); ?>" alt="<?php echo e($item->name); ?>" class="location-thumb" loading="lazy">
                                <?php else: ?>
                                    <i class="fas fa-map-marker-alt fa-lg text-muted"></i>
                                <?php endif; ?>
                            </div>
                        </td>

                        <td class="location-title-cell">
                            <div class="font-weight-bold text-dark"><?php echo e($item->name); ?></div>
                            <small class="text-muted">/<?php echo e($item->slug); ?></small>
                            <?php if($item->summary): ?>
                                <small class="text-muted d-block mt-1"><?php echo e(\Illuminate\Support\Str::limit(strip_tags($item->summary), 80)); ?></small>
                            <?php endif; ?>
                        </td>

                        <td>
                            <span class="badge badge-light border"><?php echo e($item->region ?: '—'); ?></span>
                            <?php if(is_array($item->postal_codes) && count($item->postal_codes) > 0): ?>
                                <small class="text-muted d-block mt-1"><?php echo e(count($item->postal_codes)); ?> postal code<?php echo e(count($item->postal_codes) === 1 ? '' : 's'); ?></small>
                            <?php endif; ?>
                        </td>

                        <td>
                            <span class="badge badge-<?php echo e($item->statusBadgeClass()); ?>"><?php echo e($item->statusLabel()); ?></span>
                            <?php if($isTrash && $item->deleted_at): ?>
                                <small class="text-danger d-block mt-1"><?php echo e($item->deleted_at->diffForHumans()); ?></small>
                            <?php endif; ?>
                        </td>

                        <td><span class="font-weight-bold"><?php echo e($item->sort_order); ?></span></td>

                        <td>
                            <?php if($item->published_at): ?>
                                <small class="text-dark d-block"><?php echo e($item->published_at->format('d M Y')); ?></small>
                                <small class="text-muted"><?php echo e($item->published_at->format('h:i A')); ?></small>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>

                        <td class="text-right text-nowrap">
                            <div class="btn-group btn-group-sm" role="group">
                                <?php if(!$isTrash): ?>
                                    <?php if($canView): ?>
                                        <button type="button" class="btn btn-outline-info btn-show" data-url="<?php echo e(route('admin.locations.show', $item->id)); ?>" title="View"><i class="fas fa-eye"></i></button>
                                    <?php endif; ?>

                                    <?php if($canUpdate): ?>
                                        <button type="button" class="btn btn-outline-primary btn-edit" data-url="<?php echo e(route('admin.locations.edit', $item->id)); ?>" title="Edit"><i class="fas fa-pen"></i></button>
                                    <?php endif; ?>

                                    <?php if($item->status === 'published' && $canUnpublish): ?>
                                        <button type="button" class="btn btn-outline-warning btn-status-action" data-url="<?php echo e(route('admin.locations.unpublish', $item->id)); ?>" data-label="Move to Draft" title="Move to Draft"><i class="fas fa-pause"></i></button>
                                    <?php elseif($item->status !== 'published' && $canPublish): ?>
                                        <button type="button" class="btn btn-outline-success btn-status-action" data-url="<?php echo e(route('admin.locations.publish', $item->id)); ?>" data-label="Publish" title="Publish"><i class="fas fa-play"></i></button>
                                    <?php endif; ?>

                                    <?php if($canDuplicate): ?>
                                        <button type="button" class="btn btn-outline-secondary btn-duplicate" data-url="<?php echo e(route('admin.locations.duplicate', $item->id)); ?>" title="Duplicate"><i class="fas fa-copy"></i></button>
                                    <?php endif; ?>

                                    <?php if($canDelete): ?>
                                        <button type="button" class="btn btn-outline-danger btn-delete" data-url="<?php echo e(route('admin.locations.destroy', $item->id)); ?>" title="Move to trash"><i class="fas fa-trash"></i></button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($canRestore): ?>
                                        <button type="button" class="btn btn-outline-success btn-restore" data-url="<?php echo e(route('admin.locations.restore', $item->id)); ?>" title="Restore"><i class="fas fa-undo-alt"></i></button>
                                    <?php endif; ?>

                                    <?php if($canForceDelete): ?>
                                        <button type="button" class="btn btn-outline-danger btn-force-delete" data-url="<?php echo e(route('admin.locations.force_delete', $item->id)); ?>" title="Permanently delete"><i class="fas fa-fire-alt"></i></button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr><td colspan="8"><div class="text-center py-5"><div class="mb-3"><span class="d-inline-flex align-items-center justify-content-center rounded-circle bg-light" style="width:72px;height:72px;"><i class="fas fa-map-marker-alt fa-2x text-muted"></i></span></div><h5 class="text-muted mb-1"><?php echo e($isTrash ? 'Trash bin is empty' : 'No locations found'); ?></h5><p class="text-muted small mb-0"><?php echo e($isTrash ? 'Deleted locations will appear here.' : 'Create a location or adjust your filters.'); ?></p></div></td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php if($locations->hasPages()): ?>
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between px-3 py-3 border-top"><div class="text-muted small mb-2 mb-md-0">Showing <strong><?php echo e($locations->firstItem() ?? 0); ?></strong> to <strong><?php echo e($locations->lastItem() ?? 0); ?></strong> of <strong><?php echo e($locations->total()); ?></strong> locations</div><div><?php echo e($locations->links('pagination::bootstrap-4')); ?></div></div>
<?php endif; ?>
<?php /**PATH D:\drawing\website\resources\views/backoffice/admin/locations/partials/table.blade.php ENDPATH**/ ?>