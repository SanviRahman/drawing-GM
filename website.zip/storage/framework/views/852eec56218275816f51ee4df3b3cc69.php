<?php
    $isTrash = $isTrash ?? false;
?>
<div class="table-responsive"><table class="table table-hover border-bottom pricing-addon-table mb-0 text-nowrap"><thead class="thead-light"><tr><th style="width:40px;" class="text-center"><input type="checkbox" id="checkAll"></th><th style="width:70px;">Image</th><th>Name</th><th>Price Type</th><th>Price</th><th>Status</th><th>Order</th><th style="width:190px;" class="text-right">Actions</th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php
        $imageUrl = $addon->getFirstMediaUrl(\App\Models\PricingAddon::MEDIA_COLLECTION);
        $descriptionPreview = \Illuminate\Support\Str::limit(trim(strip_tags((string) $addon->description)), 65);
    ?>
    <tr><td class="text-center"><input type="checkbox" class="row-checkbox" value="<?php echo e($addon->id); ?>"></td><td>
        <?php if($imageUrl): ?>
            <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($addon->name); ?>" class="rounded border pricing-addon-thumb">
        <?php else: ?>
            <div class="rounded border bg-light text-muted pricing-addon-empty-thumb"><i class="far fa-image"></i></div>
        <?php endif; ?>
    </td><td><strong class="d-block"><?php echo e($addon->name); ?></strong><?php if($descriptionPreview): ?><small class="text-muted"><?php echo e($descriptionPreview); ?></small><?php endif; ?></td><td><span class="badge badge-info px-2 py-1"><?php echo e($addon->price_type_label); ?></span></td><td><strong><?php echo e($addon->display_price); ?></strong></td><td><span class="badge badge-<?php echo e($addon->is_active ? 'success' : 'secondary'); ?> px-2 py-1"><?php echo e($addon->is_active ? 'Active' : 'Inactive'); ?></span></td><td><?php echo e($addon->sort_order); ?></td><td class="text-right">
        <?php if($isTrash): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_restore')): ?>
                <button type="button" class="btn btn-sm btn-outline-success btn-restore" data-url="<?php echo e(route('admin.pricing_addons.restore', $addon->id)); ?>" title="Restore"><i class="fas fa-undo"></i></button>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_force_delete')): ?>
                <button type="button" class="btn btn-sm btn-outline-danger btn-force-delete" data-url="<?php echo e(route('admin.pricing_addons.force_delete', $addon->id)); ?>" title="Delete Permanently"><i class="fas fa-times"></i></button>
            <?php endif; ?>
        <?php else: ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_view')): ?>
                <button type="button" class="btn btn-sm btn-outline-info btn-show" data-url="<?php echo e(route('admin.pricing_addons.show', $addon->id)); ?>" title="View"><i class="fas fa-eye"></i></button>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_update')): ?>
                <button type="button" class="btn btn-sm btn-outline-primary btn-edit" data-url="<?php echo e(route('admin.pricing_addons.edit', $addon->id)); ?>" title="Edit"><i class="fas fa-pen"></i></button>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_toggle')): ?>
                <button type="button" class="btn btn-sm btn-outline-warning btn-toggle" data-url="<?php echo e(route('admin.pricing_addons.toggle', $addon->id)); ?>" title="Toggle"><i class="fas fa-power-off"></i></button>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_duplicate')): ?>
                <button type="button" class="btn btn-sm btn-outline-secondary btn-duplicate" data-url="<?php echo e(route('admin.pricing_addons.duplicate', $addon->id)); ?>" title="Duplicate"><i class="fas fa-copy"></i></button>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_addon_delete')): ?>
                <button type="button" class="btn btn-sm btn-outline-danger btn-delete" data-url="<?php echo e(route('admin.pricing_addons.destroy', $addon->id)); ?>" title="Trash"><i class="fas fa-trash"></i></button>
            <?php endif; ?>
        <?php endif; ?>
    </td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="8" class="text-center py-5"><div class="text-muted"><i class="fas fa-puzzle-piece fa-3x mb-3 text-light"></i><h5 class="font-weight-bold">No pricing add-ons found</h5><p class="mb-0 small"><?php echo e($isTrash ? 'Trash is empty or no records match the filters.' : 'Create an add-on or adjust your filters.'); ?></p></div></td></tr>
<?php endif; ?>
</tbody></table></div>
<?php if($addons->hasPages()): ?>
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center px-3 py-3 border-top bg-light"><div class="text-muted small font-weight-bold mb-2 mb-md-0">Showing <?php echo e($addons->firstItem() ?? 0); ?> to <?php echo e($addons->lastItem() ?? 0); ?> of <?php echo e($addons->total()); ?> entries</div><div class="m-0 pagination-sm"><?php echo $addons->appends(request()->query())->links('pagination::bootstrap-4'); ?></div></div>
<?php endif; ?>
<?php /**PATH D:\drawing\website\resources\views/backoffice/admin/pricing_addons/partials/table.blade.php ENDPATH**/ ?>