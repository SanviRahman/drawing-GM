<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<div id="pricing-package-manager" class="container-fluid py-3">
    <div class="d-flex align-items-center flex-wrap mb-3" style="gap:6px;"><a href="<?php echo e(route('admin.pricing_packages.index')); ?>" class="btn btn-secondary btn-sm font-weight-bold shadow-sm"><i class="fas fa-arrow-left mr-1"></i>Back to Pricing Packages</a><select id="bulkAction" class="form-control form-control-sm shadow-none" style="width:210px;"><option value="">-- Bulk Actions --</option>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_package_restore')): ?>
            <option value="restore">Restore Selected</option>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pricing_package_force_delete')): ?>
            <option value="force_delete">Permanently Delete</option>
        <?php endif; ?>
    </select><button type="button" class="btn btn-secondary btn-sm font-weight-bold px-3 shadow-sm" id="applyBulk">APPLY</button></div>

    <div class="card shadow-sm border-0 mb-3"><div class="card-body px-3 py-2"><form id="filterForm" method="GET" action="<?php echo e(route('admin.pricing_packages.trashed')); ?>"><div class="row align-items-end">
        <div class="col-md-3 mb-2 mb-md-0"><label for="filter_service" class="text-muted small font-weight-bold text-uppercase mb-1">Service</label><select name="service_id" id="filter_service" class="form-control form-control-sm shadow-none"><option value="">All Services</option>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($service->id); ?>" <?php echo e((string) request('service_id') === (string) $service->id ? 'selected' : ''); ?>><?php echo e($service->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></div>
        <div class="col-md-3 mb-2 mb-md-0"><label for="filter_location" class="text-muted small font-weight-bold text-uppercase mb-1">Location</label><select name="location_id" id="filter_location" class="form-control form-control-sm shadow-none"><option value="">All Locations</option>
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($location->id); ?>" <?php echo e((string) request('location_id') === (string) $location->id ? 'selected' : ''); ?>><?php echo e($location->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></div>
        <div class="col-md-5 mb-2 mb-md-0"><label for="table_search" class="text-muted small font-weight-bold text-uppercase mb-1">Search Trashed Packages</label><div class="input-group input-group-sm"><input type="text" name="search" id="table_search" class="form-control shadow-none" value="<?php echo e(request('search')); ?>" autocomplete="off" placeholder="Search packages..."><div class="input-group-append"><button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button></div></div></div>
        <div class="col-md-1"><button type="button" class="btn btn-outline-danger btn-sm btn-block font-weight-bold shadow-sm btn-reset-filter"><i class="fas fa-sync-alt"></i></button></div>
    </div></form></div></div>

    <div class="card shadow-sm border-0"><div class="card-header bg-white px-3 py-3 border-bottom text-danger"><h3 class="card-title font-weight-bold mb-0"><i class="fas fa-trash-alt mr-1"></i>Pricing Packages Trash</h3></div><div class="card-body p-0" id="tableContainer" style="min-height:340px;"><?php echo $__env->make('backoffice.admin.pricing_packages.partials.table', ['packages' => $packages, 'isTrash' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div></div>
</div>

<?php echo $__env->make('backoffice.admin.pricing_packages.partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php echo $__env->make('backoffice.admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\drawing\website\resources\views/backoffice/admin/pricing_packages/trash.blade.php ENDPATH**/ ?>