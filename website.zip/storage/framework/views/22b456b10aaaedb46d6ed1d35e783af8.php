

<?php $__env->startSection('meta_title', 'Dashboard'); ?>

<?php $__env->startSection('page_content'); ?>
    <div class="card card-outline card-primary">
        <div class="card-body">
            <p class="mb-0">Welcome, <?php echo e($admin->name ?? 'Admin'); ?>.</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backoffice.admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\drawing\website\resources\views/backoffice/admin/dashboard.blade.php ENDPATH**/ ?>