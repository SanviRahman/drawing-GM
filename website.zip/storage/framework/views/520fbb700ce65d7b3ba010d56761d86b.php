<footer class="main-footer">
    <?php echo $__env->yieldContent('footer'); ?>
</footer><?php /**PATH D:\drawing\website\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/footer/footer.blade.php ENDPATH**/ ?>