<?php
    $isTrash = $isTrash ?? false;
    $admin = auth('admin')->user();
    $canView = $admin?->can('section_definition_view') ?? false;
    $canUpdate = $admin?->can('section_definition_update') ?? false;
    $canDelete = $admin?->can('section_definition_delete') ?? false;
    $canToggle = $admin?->can('section_definition_toggle') ?? false;
    $canRestore = $admin?->can('section_definition_restore') ?? false;
    $canForceDelete = $admin?->can('section_definition_force_delete') ?? false;
?>

<div class="table-responsive">
    <table class="table table-hover mb-0 section-definition-table">
        <thead class="thead-light"><tr><th class="text-center" style="width:45px;"><input type="checkbox" id="checkAll" aria-label="Select all"></th><th style="width:190px;">Key</th><th>Section</th><th>Schema</th><th style="width:105px;">Status</th><th style="width:135px;">Updated</th><th class="text-right" style="width:155px;">Actions</th></tr></thead>
        <tbody>
            <?php if($sectionDefinitions->count() > 0): ?>
                <?php $__currentLoopData = $sectionDefinitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $description = trim(strip_tags((string) $item->description));
                        $schemaCount = is_array($item->schema_json) ? count($item->schema_json) : 0;
                    ?>
                    <tr>
                        <td class="text-center"><input type="checkbox" class="row-checkbox" value="<?php echo e($item->id); ?>" aria-label="Select <?php echo e($item->name); ?>"></td>
                        <td><code class="font-weight-bold"><?php echo e($item->key); ?></code><small class="text-muted d-block mt-1">&lt;x-sections.<?php echo e($item->component_name); ?> /&gt;</small></td>
                        <td><div class="font-weight-bold text-dark"><?php echo e($item->name); ?></div><?php if($description !== ''): ?><small class="text-muted d-block mt-1"><?php echo e(\Illuminate\Support\Str::limit($description, 100)); ?></small><?php else: ?><small class="text-muted">No description</small><?php endif; ?></td>
                        <td><div class="schema-preview"><span class="badge badge-light border mr-1"><i class="fas fa-code mr-1"></i>JSON</span><small class="text-muted"><?php echo e($schemaCount); ?> top-level item<?php echo e($schemaCount === 1 ? '' : 's'); ?></small></div></td>
                        <td><?php if($item->is_active): ?><span class="badge badge-success px-2 py-1"><i class="fas fa-check-circle mr-1"></i>Active</span><?php else: ?><span class="badge badge-secondary px-2 py-1"><i class="fas fa-pause-circle mr-1"></i>Inactive</span><?php endif; ?></td>
                        <td><small class="text-muted"><?php echo e(optional($item->updated_at)->format('d M Y')); ?></small><?php if($isTrash && $item->deleted_at): ?><small class="text-danger d-block">Deleted <?php echo e($item->deleted_at->diffForHumans()); ?></small><?php endif; ?></td>
                        <td class="text-right text-nowrap">
                            <div class="btn-group btn-group-sm" role="group">
                                <?php if(!$isTrash): ?>
                                    <?php if($canView): ?><button type="button" class="btn btn-outline-info btn-show" data-url="<?php echo e(route('admin.section_definitions.show', $item->id)); ?>" title="View"><i class="fas fa-eye"></i></button><?php endif; ?>
                                    <?php if($canUpdate): ?><button type="button" class="btn btn-outline-primary btn-edit" data-url="<?php echo e(route('admin.section_definitions.edit', $item->id)); ?>" title="Edit"><i class="fas fa-pen"></i></button><?php endif; ?>
                                    <?php if($canToggle): ?><button type="button" class="btn btn-outline-<?php echo e($item->is_active ? 'warning' : 'success'); ?> btn-toggle" data-url="<?php echo e(route('admin.section_definitions.toggle', $item->id)); ?>" data-label="<?php echo e($item->is_active ? 'Deactivate' : 'Activate'); ?>" title="<?php echo e($item->is_active ? 'Deactivate' : 'Activate'); ?>"><i class="fas fa-<?php echo e($item->is_active ? 'pause' : 'play'); ?>"></i></button><?php endif; ?>
                                    <?php if($canDelete): ?><button type="button" class="btn btn-outline-danger btn-delete" data-url="<?php echo e(route('admin.section_definitions.destroy', $item->id)); ?>" title="Move to trash"><i class="fas fa-trash"></i></button><?php endif; ?>
                                <?php else: ?>
                                    <?php if($canRestore): ?><button type="button" class="btn btn-outline-success btn-restore" data-url="<?php echo e(route('admin.section_definitions.restore', $item->id)); ?>" title="Restore"><i class="fas fa-undo-alt"></i></button><?php endif; ?>
                                    <?php if($canForceDelete): ?><button type="button" class="btn btn-outline-danger btn-force-delete" data-url="<?php echo e(route('admin.section_definitions.force_delete', $item->id)); ?>" title="Permanently delete"><i class="fas fa-fire-alt"></i></button><?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr><td colspan="7"><div class="text-center py-5"><div class="mb-3"><span class="d-inline-flex align-items-center justify-content-center rounded-circle bg-light" style="width:72px;height:72px;"><i class="fas fa-layer-group fa-2x text-muted"></i></span></div><h5 class="text-muted mb-1"><?php echo e($isTrash ? 'Trash bin is empty' : 'No section definitions found'); ?></h5><p class="text-muted small mb-0"><?php echo e($isTrash ? 'Deleted definitions will appear here.' : 'Create a section definition or adjust your filters.'); ?></p></div></td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php if($sectionDefinitions->hasPages()): ?>
<div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between px-3 py-3 border-top"><div class="text-muted small mb-2 mb-md-0">Showing <strong><?php echo e($sectionDefinitions->firstItem() ?? 0); ?></strong> to <strong><?php echo e($sectionDefinitions->lastItem() ?? 0); ?></strong> of <strong><?php echo e($sectionDefinitions->total()); ?></strong> sections</div><div><?php echo e($sectionDefinitions->links('pagination::bootstrap-4')); ?></div></div>
<?php endif; ?>
<?php /**PATH D:\drawing\website\resources\views/backoffice/admin/section_definitions/partials/table.blade.php ENDPATH**/ ?>